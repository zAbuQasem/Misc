#!/usr/bin/python3
from importlib.abc import MetaPathFinder
import sys


class ForbiddenModules(MetaPathFinder):
    def __init__(self, modules):
        super().__init__()
        self.modules = modules

    def find_spec(self, fullname, path, target=None):
        if fullname in self.modules:
            raise ImportError(fullname)


# IDK why my manager wants me to write this function in my calculator application, I really hate this JOB!!
def weird_function() -> str:
    return open('/root/flag.txt', "rb").read()

try:
    sys.meta_path.insert(0, ForbiddenModules({'subprocess', 'os', 'sys'}))
    sys.modules.clear()
    del MetaPathFinder, ForbiddenModules, sys
    flag = weird_function()
    num1 = input("Enter the first number: ")
    num2 = input("Enter the second number: ")
    print(eval(num1 + num2))
except Exception as e:
    print(e)
    print('[!] Try Again...')

