#!/usr/bin/python3
from importlib.abc import MetaPathFinder
import sys


class ForbiddenModules(MetaPathFinder):
    def __init__(self, modules):
        super().__init__()
        self.modules = modules

    def find_spec(self, fullname, path, target=None):
        if fullname in self.modules:
            raise ImportError(fullname)


flag = open('/root/flag.txt', "rb").read().strip()

try:
    sys.meta_path.insert(0, ForbiddenModules({'subprocess', 'os', 'sys'}))
    sys.modules.clear()
    del MetaPathFinder, ForbiddenModules, sys
    nope = ["p", "ord", "eval", "e"]
    num1 = input("Enter the first number: ")
    if num1 in nope:
        print('[!] Try Again...')
        exit(1)
    else:
        print(eval(num1))
except Exception as e:
    print('[!] Try Again...')

