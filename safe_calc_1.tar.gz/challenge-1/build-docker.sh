#!/bin/bash
sudo docker build -t safe_calc .
sudo docker exec -it $(sudo docker run --rm -d --name safe_calc safe_calc) /bin/bash
sudo docker stop safe_calc
