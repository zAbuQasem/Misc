#!/bin/bash
sudo docker build -t cats .
clear
sudo docker run --rm -it --name cats cats
