#!/usr/bin/python3

print("Welcome Again!", end="\n\n")

class meow:
    def __init__(self):
        self.name = "Cat"
        self.job = "NetCat"

obj = meow()

blocklist = ['.', '\\', '[', ']', '{', '}',':', 'import', 'blocklist','globals', 'compile' , 'eval','exec','breakpoint','lambda','print', 'flag']

while True:
    cmd = input('>>> ')
    if any([b in cmd for b in blocklist]):
        print('Try Harder or Learn Harder!')
    else:
        try:
            print(eval(cmd))
            if obj.age == 1337:
                flag = open('/root/flag.txt', "r").read().strip()
                print(f"[+] Good job!!\n{flag}")
        except Exception:
            pass
