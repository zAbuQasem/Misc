#!/bin/bash
docker stop zeyad-workshop
./build-docker.sh
docker exec -it zeyad-workshop bash -c "su khaled"
