#!/bin/bash
sudo docker stop zeyad-workshop
./build-docker.sh
sudo docker exec -it zeyad-workshop /bin/bash