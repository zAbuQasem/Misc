#!/bin/bash
cat /etc/passwd | grep bash | grep -v root | grep -v jenkins | grep -v postgres | cut -d ":" -f1 > username.txt
sudo docker build -t zeyad-workshop .
# Mount is not necessary beacuase of copy
sudo docker run --rm -d -h worskhop-ctf --name zeyad-workshop zeyad-workshop