#!/bin/bash
cat /etc/passwd | grep bash | grep -v root | grep -v meow | cut -d ":" -f1 > username.txt
docker build -t zeyad-workshop .
# Mount is not necessary beacuase of copy
docker run --rm -d -p 8080:80 --name zeyad-workshop zeyad-workshop
docker exec zeyad-workshop bash "/MOUNTED/postscript.sh"
