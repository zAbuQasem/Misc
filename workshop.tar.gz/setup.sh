#!/bin/bash -xe

apt update
apt upgrade -y
apt install -y whois zip curl net-tools apache2 p7zip-full p7zip-rar 

echo "[!] Setting up users and groups"
echo "CREATE_HOME yes" >> /etc/login.defs
groupadd admins
groupadd developers
useradd -d /home/mohammad -p `mkpasswd 'm123'` mohammad -G admins -s /bin/bash -m
useradd -d /home/omar -p `mkpasswd 'o123'` omar -G adm -s /bin/bash -m
useradd -d /home/khaled -p `mkpasswd 'k123'` khaled -G developers -s /bin/bash -m

# Challenges 
mkdir /opt/challenges
chmod 777 /opt/challenges

cd /opt/challenges
chown -R khaled:admins ./ 
mkdir -p challenges2/challenges3/challenges4
for i in {1..26};do touch file-"$i".txt ;done
for i in {1..34};do touch file-"$i".jpg ;done
for i in {1..40};do touch .file-"$i".config ;done
for i in {1..4};do echo -n "AbuQasem-$i" | md5sum > file-"$i".txt ;done
# Stage 2
for i in {1..26};do touch challenges2/file2-"$i".txt ;done
for i in {1..34};do touch challenges2/file2-"$i".jpg ;done
for i in {1..40};do touch challenges2/.file2-"$i".config ;done
for i in {1..4};do echo -n "AbuQasem-$i" | md5sum > challenges2/file2-"$i".txt ;done
#stage 3
for i in {1..26};do touch challenges2/challenges3/file3-"$i".txt ;done
for i in {1..34};do touch challenges2/challenges3/file3-"$i".jpg ;done
for i in {1..40};do touch challenges2/challenges3/.file3-"$i".config ;done
for i in {1..4};do echo -n "AbuQasem-$i" | md5sum > challenges2/challenges3/file3-"$i".txt ;done

# Log parsing
ip=$(ifconfig | grep "inet 172" | cut -d 'i' -f2 | cut -d " " -f2)
sed -i "s/IP/$ip/g" /MOUNTED/scripts/createlogs.sh
bash /MOUNTED/scripts/createlogs.sh

# Tar thing
mkdir /opt/Compression
cd /opt/Compression
chown -R khaled:admins /opt/Compression 
echo "[+] Congratulations $(cat /MOUNTED/username.txt)" > file.jpg
echo "$(cat /MOUNTED/username.txt | md5sum)" >> file.jpg
tar -zcvf compressed.json file.jpg
tar -cvf  meow.jpg compressed.json
zip hello.tar.gz meow.jpg
7z a why-im-alive.com hello.tar.gz
rm {file.jpg,compressed.json,meow.jpg,hello.tar.gz}
