#!/bin/bash -xe

apt update
apt upgrade -y
apt install -y whois zip p7zip-full p7zip-rar file sudo

# Objective
echo -e "Hello Hacker!!\nWe got an incident last tuesday, Someone managed to utilize a Zero-Day vulnerablity to hack our servers!\nThe intruder main objective was to ruin our systems and unfortunelty he did :(\nWe need your help to retrieve some important file contents!\nWe believe in your skills ;)\n\nIn order to help you we have created a \"hidden\" file named \"credentials.txt\",This file contain Some users credential to help you throught your analysis." > /opt/Important.txt

echo -e "mohammad:m123\nomar:o123\nkhaled:k123" > /opt/.credentials.txt

function users
{
	echo "[!] Setting up users and groups"
	echo "CREATE_HOME yes" >> /etc/login.defs
	groupadd admin
	groupadd parsers
	useradd -d /home/mohammad -p `mkpasswd 'm123'` mohammad -G parsers -s /bin/bash -m
	useradd -d /home/omar -p `mkpasswd 'o123'` omar -G adm -s /bin/bash -m
	useradd -d /home/khaled -p `mkpasswd 'k123'` khaled -G sudo -s /bin/bash -m
} && users

function grepper
{
	mkdir /opt/challenge1
	cd /opt/challenge1
	mkdir -p folder2/folder3
	for i in {1..26};do touch file-"$i".txt ;done
	for i in {1..34};do touch file-"$i".jpg ;done
	for i in {1..40};do touch .file-"$i".config ;done
	for i in {1..29};do touch folder2/folder3/.file3-"$i".pdf ;done
	for i in {1..4};do echo -n "AbuQasem-$i" | md5sum > file-"$i".txt ;done
	# Stage 2
	for i in {1..26};do touch folder2/file2-"$i".txt ;done
	for i in {1..34};do touch folder2/file2-"$i".jpg ;done
	for i in {1..40};do touch folder2/.file2-"$i".config ;done
	for i in {1..29};do touch folder2/folder3/.file3-"$i".pdf ;done
	for i in {1..4};do echo -n "AbuQasem-$i-$i" | md5sum > folder2/file2-"$i".txt ;done
	#stage 3
	for i in {1..26};do touch folder2/folder3/file3-"$i".txt ;done
	for i in {1..34};do touch folder2/folder3/file3-"$i".jpg ;done
	for i in {1..40};do touch folder2/folder3/.file3-"$i".config ;done
	for i in {1..29};do touch folder2/folder3/.file3-"$i".pdf ;done
	for i in {1..4};do echo -n "AbuQasem-$i-$i-$i" | md5sum > folder2/folder3/file3-"$i".txt ;done
	echo -e "Hello Hacker, Unfortunelty the intruder managed to hide the flag in one of the files in this directory or in one of the sub-directories!\nCan you retrieve the flag?\n\n[Note] As far as i know, the flag start with the following prefix => flag{" > Description.txt
	echo -e "[+] Congratulations $(cat /MOUNTED/username.txt) Great JOB!!!" > folder2/folder3/file3-26.pdf
	echo "Here is your flag => flag{$(cat /MOUNTED/username.txt|md5sum | cut -d " " -f1)}" >> folder2/folder3/file3-26.pdf
	chown -R root:parsers ./
	chmod -R 770 ./
} && grepper


function tarmylife
{
	mkdir /opt/challenge2
	cd /opt/challenge2
	echo -e "[+] Congratulations $(cat /MOUNTED/username.txt) Great JOB!!!" > flag.jpg
	echo "Here is your flag => flag{$(cat /MOUNTED/username.txt|md5sum | cut -d " " -f1)}" >> flag.jpg
	tar -zcvf compressed.json flag.jpg
	tar -cvf  meow.jpg compressed.json
	zip hello.tar.gz meow.jpg
	7z a why-im-alive.com hello.tar.gz
	rm {flag.jpg,compressed.json,meow.jpg,hello.tar.gz}
	echo -e "Hello Hacker, The intruder compressed the file containing the flag multiple times, and you have to decompress them somehow to retrieve the flag!\n\n[Note] An experienced sysadmin told us that we can use 'file' command to know file types. i think this could help you somehow.\n\n[Note-2] My friend told me the other day that linux doesn't care about extensions." > Description.txt
	chown -R khaled:root /opt/challenge2
	chmod -R 770 ./
} && tarmylife
