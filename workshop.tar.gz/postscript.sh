#!/bin/bash
echo "[!] Setting up files and directories"
mkdir /opt/Configurations
mkdir /var/www/html/web-application
echo "[+] Good job $(cat /MOUNTED/username.txt)" > /opt/Configurations/IMPORTANT_INFO.txt
echo "[+] Good job $(cat /MOUNTED/username.txt | md5sum)" >> /opt/Configurations/IMPORTANT_INFO.txt
echo "[+] Good job $(cat /MOUNTED/username.txt)" > /var/www/html/web-application/IMPORTANT_INFO.html
echo "[+] Good job $(cat /MOUNTED/username.txt | md5sum)" >> /var/www/html/web-application/IMPORTANT_INFO.html
chown -R omar:admins /opt/Configurations
chmod -R 770 /opt/Configurations
chown -R khaled:developers /var/www/html/web-application 
chmod -R 770 /var/www/html/web-application 
